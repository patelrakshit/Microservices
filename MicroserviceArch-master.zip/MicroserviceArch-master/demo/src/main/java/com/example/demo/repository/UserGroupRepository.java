// package com.example.demo.repository;
// import java.util.List;

// import com.example.demo.entity.UserGroup;
// import org.springframework.data.jpa.repository.JpaRepository;
// import org.springframework.stereotype.Repository;
// // import java.util.List;

// @Repository
// public interface UserGroupRepository extends JpaRepository<UserGroup, Integer>{


  
// }
